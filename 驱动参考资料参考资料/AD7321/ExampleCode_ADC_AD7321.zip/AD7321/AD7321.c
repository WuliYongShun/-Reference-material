
/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date :  Jan, 2013

 File name :  AD7321.c

 Description :	Configure the regisiters of AD7321, and read the convention data. 

 Hardware plateform : 	ADUc7026 Eval Board Rev.B1 + AD7321 test board(hand made)
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"
#include "AD7321.h"




/********************************************************************************
 Function: 	 AD7321_read_write

 Parameter:  unsigned char spi_mosiValue

 Return value :	 unsigned char

 Description :	Configure the regisiters of AD7321, and read the convention data. 
********************************************************************************/
unsigned int AD7321_read_write(unsigned int spi_mosiValue)
{
	unsigned int   no,
	spi_misoValue;
	
	set_spi_cs();
    
	clr_spi_cs();  
  
	for(no=0;no<16;no++)  
	{  
   		set_spi_clk(); 
		   
  		spi_misoValue = (spi_misoValue << 1);

   		if((spi_mosiValue & 0x8000)==0x8000)  
     		set_spi_mosi();  
   		else  
     		clr_spi_mosi();  

		if(read_spi_miso() == read_spi_miso_HIGH)  
         	spi_misoValue |= 0x0001;  
     	else  
         	spi_misoValue &= ~0x0001;
   		clr_spi_clk();   
  		
   		spi_mosiValue = (spi_mosiValue << 1);  
		delay(1);

	} 

	set_spi_clk();

	set_spi_cs();

	return  (spi_misoValue & 0x0000FFFF); 

}


