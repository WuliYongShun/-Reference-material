/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date :  Jan, 2013

 File name :  ADuC7026Driver.c

 Description :	Configure the regisiters of AD7321, and read the convention data. 

 Hardware plateform : 	ADUc7026 Eval Board Rev.B1 + AD7321 test board(hand made)
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"

/*    Function Pointers for Interrupts  */
// Copied from irq_arm.c in Keil uV4, required 
tyVctHndlr    IRQ     = (tyVctHndlr)0x0;
tyVctHndlr    SWI     = (tyVctHndlr)0x0;
tyVctHndlr    FIQ     = (tyVctHndlr)0x0;
tyVctHndlr    UNDEF   = (tyVctHndlr)0x0;
tyVctHndlr    PABORT  = (tyVctHndlr)0x0;
tyVctHndlr    DABORT  = (tyVctHndlr)0x0;

void	IRQ_Handler   (void) __irq;
void	SWI_Handler   (void) __irq;
void	FIQ_Handler   (void) __irq;
void	Undef_Handler (void) __irq;
void	PAbt_Handler  (void) __irq;
void	DAbt_Handler  (void) __irq;

void	IRQ_Handler(void) __irq
{
	if ( *IRQ !=0x00)
	{
		IRQ();
	}
}

void	FIQ_Handler(void) __irq
{
	if ( *FIQ !=0x00)
	{
		FIQ();
	}
}

void	SWI_Handler(void) __irq
{
	if ( *SWI !=0x00)
	{
		SWI();
	}
}

void	Undef_Handler(void)__irq 
{
	if ( *UNDEF !=0x00)
	{
		UNDEF();
	}
}

void	PAbt_Handler(void) __irq
{
	if ( *PABORT !=0x00)
	{
		PABORT();
	}
}

void	DAbt_Handler(void) __irq
{
	if ( *DABORT !=0x00)
	{
		DABORT();
	}
}
/*    Function Pointers for Interrupts  */

// add the c file here
/********************************************************************************
 Function: 	 UrtTx

 Parameter:  char data

 Return value :	 none

 Description :	uart send a byte. 
********************************************************************************/
void UrtTx(unsigned char ch)/* Write character to Serial Port  */  
{          
	COMTX = ch;				 //COMTX is an 8-bit transmit register.
    while(!(0x020==(COMSTA0 & 0x020)))
    {;}
}

/********************************************************************************
 Function: 	 delay_ms

 Parameter:  unsigned int time

 Return value :	 none

 Description :	generater a time delay, for several milliseconds. 
********************************************************************************/
void delay_ms(unsigned int time)
{
 	unsigned int i,j;
  	for(i=0;i<time;i++) 
 	{
 		for(j=0;j<3750;j++){}
 	}
}

/********************************************************************************
 Function: 	 delay

 Parameter:  unsigned int reg_value, unsigned char reg_address

 Return value :	 none

 Description :	generater a time delay, for several cycles.  
********************************************************************************/
void delay(unsigned int time)
{	
	unsigned int i;
	for(i=0;i<time;i++) {}
}

/********************************************************************************
 Function: 	 system_init

 Parameter:  none

 Return value :	 none

 Description :	Configure ADuC7026 for the system clock. internal PLL and 41.78 MHz 
 				P4.0->CS��P4.1->SCLK��P4.2->DIN��P4.3->DOUT. 
********************************************************************************/
void system_init(void)
{
	PLLKEY1 = 0xAA;
	PLLCON = 0x01;						//internal PLL
	PLLKEY2 = 0x55;						
	POWKEY1 = 0x01;
	POWCON = 0x00;						//41.78 MHz
	POWKEY2 = 0xF4;	

	GP1CON = 0x00000011;		//CONFIG P1.6 P1.5 P1.4  as GPIO  P1.1 P1.O  as com
	//UART Initial��Baud Rate = 9600
	COMCON0 = 0x80;  
	COMDIV0 = 0x88;    		
	COMDIV1 = 0x00;
	COMCON0 = 0x07; 

	GP4CON = 0x00000000;				// P4 configured as an GPIO
	GP4DAT = 0xFB000000;				// P4.0->CS��P4.1->SCLK��P4.2->DIN��P4.3->DOUT

}
/*
*/
