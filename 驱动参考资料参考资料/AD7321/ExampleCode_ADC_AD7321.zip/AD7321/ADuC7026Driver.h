
/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date :  Jan, 2013

 File name :  ADuC7026Driver.h

 Description :	Configure the regisiters of AD7321, and read the convention data. 

 Hardware plateform : 	ADUc7026 Eval Board Rev.B1 + AD7321 test board(hand made)
********************************************************************************/

#ifndef ADUC7026_DRIVER_H
#define ADUC7026_DRIVER_H

// add the header file here

void system_init(void);
void delay(unsigned int );
void delay_ms(unsigned int );

void UrtTx(unsigned char );


/*******P4.0->CS��P4.1->SCLK��P4.2->DIN��P4.3->DOUT*****/
#define set_spi_cs()		GP4DAT |= 0x00010000
#define clr_spi_cs()		GP4DAT &= ~0x00010000
#define set_spi_clk()       GP4DAT |= 0x00020000
#define clr_spi_clk()       GP4DAT &= ~0x00020000 
#define set_spi_dout() 		GP4DAT |= 0x00080000 
#define clr_spi_dout() 		GP4DAT &= ~0x00080000
#define read_spi_di()		(GP4DAT & 0x00000004)    
#define read_spi_di_HIGH		0x00000004 

#define set_spi_mosi()		set_spi_dout() 		
#define clr_spi_mosi()		clr_spi_dout() 		
#define read_spi_miso()		read_spi_di()		   
#define read_spi_miso_HIGH	read_spi_di_HIGH	
/*
*/

#endif





