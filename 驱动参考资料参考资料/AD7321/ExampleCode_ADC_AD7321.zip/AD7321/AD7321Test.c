
/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date :  Jan, 2013

 File name :  AD7321Test.c

 Description :	Configure the regisiters of AD7321, and read the convention data. 

 Hardware plateform : 	ADUc7026 Eval Board Rev.B1 + AD7321 test board(hand made)
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"
#include "AD7321.h"


int main(void)
{
	unsigned int value;

	system_init();	

	/*************Configure CONTROL_REGISTER*******************/
	AD7321_read_write(CONTROL_REGISTER | ADD0_VIN0 | SINGLE_ENDED | NORMAL_MODE | SEQUENCER_NOT_USED | TWOS_COMPLEMENT_CODING | INTERNAL_REF);
	/*************Configure RANGE_REGISTER*******************/
	AD7321_read_write(RANGE_REGISTER | VIN0_5V);

	while(1)
	{	
		UrtTx(0xAA);
		value = AD7321_read_write(CONVENTION);	//start convention
		UrtTx(value); 							//send the convention data to PC by UART
		UrtTx((value>>8)&0xFF); 
		delay(200);
	} 	   
}
